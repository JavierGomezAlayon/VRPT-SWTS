// Universidad de La Laguna
// Escuela Superior de Ingeniería y Tecnología
// Grado en Ingeniería Informática
// Asignatura: DAA
// Curso: 3º
// Práctica 05 : VRPT-SWTS
// Autor: javier Gómez Alayón
// Correo: alu0101562445@ull.edu.es
// Fecha: 03/25/25
// Archivo Tv.cc: Implementación de Tv
//        En este fichero se implementa las funciones de la clase Tv
//
// Historial de revisiones
//        03/25/25 - Creación (primera versión) del código

#include"Tv.h"

/** Tv::Tv()
  * @brief Crea el objeto de la clase Tv.
  * @param 
  * @return objeto de la clase Tv
  */
Tv::Tv() {

}
