- [x] Añadir toda la lógica de Zona y sus hijos
- [x] Añadir la lógica de la clase de DistanciaZonas
- [x] Reemplazar todo para que El algoritmo lo ejecute un objeto Algoritmo
- [ ] Hacer los distintos algoritmos 1, 2, 3 y Grasp (**semana 1**)
  - [ ] Hacer las clases de las Rutas independientemente
  - [ ] Hacer la clase del vehículo de transporte
- [ ] Hacer el Grasp con **Búsquedas locales**
- [ ] Hacer que Problema gestione y ponga las tablas resultado de los distintos algoritmos
- [ ] Hacer el informe hasta lo que llevo hecho.
- [ ] Hacer el main con un menú que interactue con el objeto Problema para resolver el problema que quieras o generar las tablas que quieras, de la forma que quieras.
- [x] Quitar todos los ficheros de la anterior estructura.


construyes con grasp
haces busqueda local swap dentro del vector y depsués se hace el VND